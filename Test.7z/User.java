import java.util.ArrayList;

public interface User
{
    public int getSSN();
    
    public int getBorrowedCnt();
    
    public void setBorrowedCnt(int borrowedCnt);
    
    public String getName();
    
    public ArrayList<Integer> getBookList();
}
