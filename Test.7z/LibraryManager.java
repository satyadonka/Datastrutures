public interface LibraryManager
{
    
    public void addBook(Book book);
    
    public void registerUser(String userName,int regNo);
    
    public void lendBookTo(User user, Book book);
    
    public void bookReturn(User user, Book book);
    
    public Book getBook(String title, String type);
    
    public User getUser(String name);
    
}
