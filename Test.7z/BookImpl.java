
public class BookImpl implements Book
{
    
    public int getBookNo() {
        return bookNo;
    }
    
    public void setBookNo(int bookNo) {
        this.bookNo = bookNo;
    }
    
    String title = "", author = "";
    int bookNo = 0;
    
    public BookImpl(String title, String author, int bookNo)
    {
        this.title = title;
        this.author = author;
        this.bookNo = bookNo;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getAuthor() {
        return author;
    }
    
    public void setAuthor(String author) {
        this.author = author;
    }
    
    @Override
    public int getBookNumber() {
        // TODO Auto-generated method stub
        return bookNo;
    }
    
}
