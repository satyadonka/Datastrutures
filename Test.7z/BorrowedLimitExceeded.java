
public class BorrowedLimitExceeded extends RuntimeException
{
    public BorrowedLimitExceeded()
    {
        super("BorrowedLimitExceeded");
    }
    
    public String toString() {
        return "BorrowedLimitExceeded";
    }
}
