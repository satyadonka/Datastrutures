import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class LibraryManagerImpl implements LibraryManager
{
    HashMap<String, ArrayList<Book>> booksTable = new HashMap<String, ArrayList<Book>>();
    HashMap<String, ArrayList<User>> userTable = new HashMap<String, ArrayList<User>>();
    static int barrowCnt = 2;
    static int userssn = 0, bookno = 0;
    
    public void addBook(Book book) {
        ArrayList<Book> aux = booksTable.get(book.getAuthor());
        if (aux == null)
        {
            aux = new ArrayList<Book>();
        }
        aux.add(book);
        booksTable.put(book.getAuthor(), aux);
    }
    
    public void registerUser(String userName,int regNo) {
        ArrayList<User> aux = userTable.get(userName);
        User user=new UserImpl(regNo, userName);
        if (aux == null)
        {
            aux = new ArrayList<User>();
        }
        aux.add(user);
        userTable.put(user.getName(), aux);
    }
    
    public void lendBookTo(User user, Book book) {
        if (user.getBorrowedCnt() >= barrowCnt)
        {
            throw new BorrowedLimitExceeded();
        }
        user.getBookList().add(book.getBookNumber());
        user.setBorrowedCnt(user.getBorrowedCnt() + 1);
    }
    
    public void bookReturn(User user, Book book) {
        user.getBookList().remove((Integer) book.getBookNumber());
        user.setBorrowedCnt(user.getBorrowedCnt() - 1);
    }
    
    @Override
    public Book getBook(String namrortitle, String type) {
        // TODO Auto-generated method stub
        if ("title".equalsIgnoreCase(type))
        {
            Set set = booksTable.keySet();
            Iterator iterator = set.iterator();
            String key = "";
            while (iterator.hasNext())
            {
                key = (String) iterator.next();
                ArrayList<Book> aux = booksTable.get(key);
                int len = aux.size();
                for (int i = 0; i < len; i++)
                {
                    Book b = aux.get(i);
                    if (namrortitle.equalsIgnoreCase(b.getTitle()))
                    {
                        return b;
                    }
                }
            }
        }
        if ("author".equalsIgnoreCase(type))
        {
            if (booksTable.get(namrortitle) != null)
            {
                return (Book) booksTable.get(namrortitle).get(0);
            }
        }
        return null;
    }
    
    @Override
    public User getUser(String name) {
        // TODO Auto-generated method stub
        ArrayList<User> aux = userTable.get(name);
        int len = aux.size();
        for (int i = 0; i < len; i++)
        {
            System.out.println(aux.get(i));
        }
        return aux.get(0);
    }
    
}
