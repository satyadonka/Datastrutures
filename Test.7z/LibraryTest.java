import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LibraryTest
{
    
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        LibraryManager lm = new LibraryManagerImpl();
        System.out.println("1: ADD BOOK\n" + "2:ADD USER\n" + "3:LEND BOOK\n" + "4:RETURN BOOK\n"
                + "0:books borrowed by user\n" + "5:SERACH BOOK\n" + "6:SEARCH USER");
        int op = 0;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try
        {
            while (true)
            {
                System.out.println("Enter you Option");
                op = Integer.parseInt(br.readLine());
                System.out.println("Enter you Option");
                op = Integer.parseInt(br.readLine());
                
                switch (op)
                {
                    case 0:
                        System.out.println("Enter Number of Books Borrowed by User. ");
                        LibraryManagerImpl.barrowCnt = Integer.parseInt(br.readLine());
                        break;
                    case 1:
                        System.out.println("Enter Title");
                        String title = br.readLine();
                        System.out.println("Enter Author");
                        String author = br.readLine();
                        System.out.println("Enter Book Number");
                        int bno = Integer.parseInt(br.readLine());
                        if (bno == 0)
                        {
                            LibraryManagerImpl.barrowCnt++;
                            lm.addBook(new BookImpl(title, author, LibraryManagerImpl.barrowCnt));
                        } else
                        {
                            lm.addBook(new BookImpl(title, author, bno));
                        }
                        break;
                    case 2:
                        System.out.println("Enter SSN:");
                        int ssn = Integer.parseInt(br.readLine());
                        System.out.println("Enter Name");
                        String name = br.readLine();
                        lm.registerUser(name, ssn);
                        break;
                    case 3:
                        System.out.println("Enter User Name:");
                        name = br.readLine();
                        System.out.println("Enter :Title OR auther ");
                        String ut = br.readLine();
                        if ("Title".equalsIgnoreCase(ut))
                        {
                            System.out.println("Enter Book Title:");
                            title = br.readLine();
                            lm.lendBookTo(lm.getUser(name), lm.getBook(title, "title"));
                        } else
                        {
                            System.out.println("Enter Book Author:");
                            title = br.readLine();
                            lm.lendBookTo(lm.getUser(name), lm.getBook(title, "author"));
                            
                        }
                        break;
                    case 4:
                        System.out.println("Enter User Name");
                        name = br.readLine();
                        System.out.println("Enter Book Title:");
                        title = br.readLine();
                        lm.bookReturn(lm.getUser(name), lm.getBook(title, "title"));
                        break;
                    case 5:
                        System.out.println("Enter the Book title");
                        title = br.readLine();
                        Book b = lm.getBook(title, "title");
                        System.out.println("Enter Author:");
                        author = br.readLine();
                        b = lm.getBook(title, "author");
                        break;
                    case 6:
                        System.out.println("Enter User Name");
                        name = br.readLine();
                        User u = lm.getUser(name);
                        break;
                }
                
            }
        } catch (NumberFormatException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
}
