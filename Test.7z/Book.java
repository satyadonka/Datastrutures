
public interface Book
{
    public int getBookNumber();
    
    public String getAuthor();
    
    public String getTitle();
}
