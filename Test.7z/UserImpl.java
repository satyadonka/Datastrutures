import java.util.ArrayList;

public class UserImpl implements User
{
    ArrayList<Integer> bookList = new ArrayList<Integer>();
    int ssn = 0;
    
    public UserImpl(int ssn, String name)
    {
        this.ssn = ssn;
        this.name = name;
    }
    
    public void setSsn(int ssn) {
        this.ssn = ssn;
    }
    
    public ArrayList<Integer> getBookList() {
        return bookList;
    }
    
    public void setBookList(ArrayList<Integer> bookList) {
        this.bookList = bookList;
    }
    
    String name = "";
    int borrowedCnt = 0;
    
    public int getBorrowedCnt() {
        return borrowedCnt;
    }
    
    public void setBorrowedCnt(int borrowedCnt) {
        this.borrowedCnt = borrowedCnt;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    @Override
    public int getSSN() {
        // TODO Auto-generated method stub
        return ssn;
    }
    
    public String toString() {
        return "name:" + name + " SSN:" + ssn;
    }
}
